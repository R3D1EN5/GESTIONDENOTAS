EMAIL_HOST = "smtp.gmail.com"
EMAIL_PORT = 587
EMAIL_HOST_USER = "kevin.esteban.cuero@correounivalle.edu.co"
EMAIL_HOST_PASSWORD = "1234"